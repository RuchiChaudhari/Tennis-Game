import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class TennisGame extends JPanel implements ActionListener {
    private int ballX = 50;
    private int ballY = 50;
    private int ballSpeedX = 3;
    private int ballSpeedY = 2;

    private int paddle1Y = 150;
    private int paddle2Y = 150;
    private int paddleSpeed = 2;

    private int player1Score = 0;
    private int player2Score = 0;

    private boolean gameRunning = true;

    public TennisGame() {
        Timer timer = new Timer(10, this);
        timer.start();

        addKeyListener(new TennisKeyListener());
        setFocusable(true);
        setFocusTraversalKeysEnabled(false);

        setPreferredSize(new Dimension(700, 400)); // Set preferred size for the panel
        setFocusable(true);
        requestFocus(); // Request focus for key events
    }

    public void actionPerformed(ActionEvent e) {
        if (gameRunning) {
            moveBall();
            movePaddles();
            checkCollision();
            repaint();
        }
    }

    private void moveBall() {
        ballX += ballSpeedX;
        ballY += ballSpeedY;

        if (ballX <= 0 || ballX >= 680) {
            ballSpeedX = -ballSpeedX;
        }
        if (ballY <= 0 || ballY >= 380) {
            ballSpeedY = -ballSpeedY;
        }
    }

    private void movePaddles() {
        if (paddle1Y > 0 && paddle1Y < 320) {
            paddle1Y += paddleSpeed;
        }

        if (paddle2Y > 0 && paddle2Y < 320) {
            paddle2Y += paddleSpeed;
        }
    }

    private void checkCollision() {
        if (ballX <= 50) {
            if (ballY >= paddle1Y && ballY <= paddle1Y + 80) {
                ballSpeedX = -ballSpeedX;
                player1Score++;
            }
        }

        if (ballX >= 620) {
            if (ballY >= paddle2Y && ballY <= paddle2Y + 80) {
                ballSpeedX = -ballSpeedX;
                player2Score++;
            }
        }
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        g.setColor(Color.BLACK);
        g.fillRect(0, 0, 700, 400);

        g.setColor(Color.WHITE);
        g.fillRect(340, 0, 10, 400);

        g.fillRect(50, paddle1Y, 10, 80);
        g.fillRect(640, paddle2Y, 10, 80);

        g.fillOval(ballX, ballY, 20, 20);

        g.setFont(new Font("Arial", Font.PLAIN, 20));
        g.drawString("Player 1: " + player1Score, 100, 50);
        g.drawString("Player 2: " + player2Score, 500, 50);

        if (player1Score >= 5 || player2Score >= 5) {
            g.setFont(new Font("Arial", Font.BOLD, 50));
            g.drawString("Game Over", 280, 200);
            gameRunning = false;
        }
    }

    private class TennisKeyListener implements KeyListener {
        @Override
        public void keyTyped(KeyEvent e) {
        }

        @Override
        public void keyPressed(KeyEvent e) {
            if (e.getKeyCode() == KeyEvent.VK_UP) {
                if (paddle2Y > 0) {
                    paddle2Y -= 10;
                }
            } else if (e.getKeyCode() == KeyEvent.VK_DOWN) {
                if (paddle2Y < 320) {
                    paddle2Y += 10;
                }
            } else if (e.getKeyCode() == KeyEvent.VK_W) {
                if (paddle1Y > 0) {
                    paddle1Y -= 10;
                }
            } else if (e.getKeyCode() == KeyEvent.VK_S) {
                if (paddle1Y < 320) {
                    paddle1Y += 10;
                }
            }
        }

        @Override
        public void keyReleased(KeyEvent e) {
        }
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Tennis Game");
        TennisGame game = new TennisGame();
        frame.add(game);
        frame.pack(); // Automatically set the frame size
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
